#######
Support
#######

Getting Help
************

The easiest way to get help with the project is to open an issue on Github_.

The forum_ is also available for support.

.. _Github: http://github.com/jookies/jasmin/issues
.. _forum: https://groups.google.com/forum/#!forum/jasmin-sms-gateway

Commercial Support
******************

We offer commercial support for Jasmin_, commercial solution hosting, as well as remote and on-site consulting and engineering.

You can contact us at support@jasminsms.com to learn more.

.. _Jasmin: http://www.jasminsms.com
